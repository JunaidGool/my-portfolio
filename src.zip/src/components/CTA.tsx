// src/components/CTA.tsx
"use client";

import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Coffee } from "lucide-react";

export default function CTA() {
  return (
    <section className="bg-gradient-to-r from-brand-primary-500 to-brand-accent-500">
      <div className="container mx-auto px-6">
        {" "}
        {/* centers & pads the card */}
        <div
          className="
            rounded-2xl 
            bg-[#0F172A] 
            px-12 py-10 
            text-white 
            shadow-lg 
            ring-1 ring-brand-primary-500/30
            flex items-center justify-between gap-8
          "
        >
          {/* 1) Headline: never wraps, never shrinks */}
          <h2 className="text-step-3 font-semibold whitespace-nowrap flex-shrink-0">
            Start a project
          </h2>

          {/* 2) Copy: exact two lines via <br/> */}
          <p className="flex-1 text-step--1 text-white/90">
            Interested in working together? We should queue up a time to chat.
            <br />
            I’ll buy the coffee.
          </p>

          {/* 3) Button: unchanged */}
          <Button
            asChild
            size="lg"
            variant="outline"
            className="
              flex-shrink-0 
              flex items-center gap-2 rounded-full border-2
              border-brand-accent-500 px-8 py-3
              hover:bg-brand-accent-500/10 transition
            "
          >
            <Link
              href="mailto:junaid@example.com"
              className="flex items-center"
            >
              <Coffee className="h-4 w-4 text-white" />
              Let’s do this
            </Link>
          </Button>
        </div>
      </div>
    </section>
  );
}
