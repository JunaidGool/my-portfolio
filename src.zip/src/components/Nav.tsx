"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { Menu } from "lucide-react";
import Image from "next/image";

import {
  Sheet,
  SheetTrigger,
  SheetContent,
  SheetHeader,
  SheetClose,
  SheetTitle, // 👈 added for a11y
} from "@/components/ui/sheet";

export default function Nav() {
  const pathname = usePathname() || "/";

  /* ------------ link class helpers ------------ */
  const base =
    "transition underline-offset-8 decoration-transparent hover:decoration-brand-primary-500";
  const active =
    "font-semibold decoration-2 decoration-gradient-to-r from-brand-primary-500 to-brand-accent-500";

  const links = [
    { href: "/", label: "Home" },
    { href: "/products", label: "Products" },
    { href: "/contact", label: "Contact" },
  ];

  return (
    <header className="sticky top-0 z-30 bg-white ring-1 ring-gray-200">
      <nav className="mx-auto flex max-w-7xl items-center justify-between px-6 py-3 sm:px-16">
        {/* ---------- Brand mark ---------- */}
        <Link href="/" className="flex items-center gap-2 group">
          <Image
            src="/brand/logo_JG.png"
            alt="JG logo"
            width={50}
            height={50}
            priority
            className="h-25 w-25"
          />
        </Link>

        {/* ---------- Desktop links ---------- */}
        <ul className="hidden items-center gap-8 md:flex">
          {links.map(({ href, label }) => {
            const isActive =
              href === "/" ? pathname === "/" : pathname.startsWith(href);
            return (
              <li key={href}>
                <Link
                  href={href}
                  className={`${base} ${isActive ? active : ""}`}
                >
                  {label}
                </Link>
              </li>
            );
          })}
        </ul>

        {/* ---------- Mobile hamburger ---------- */}
        <Sheet>
          <SheetTrigger asChild>
            <button
              aria-label="Open navigation menu"
              className="md:hidden rounded-md p-2 hover:bg-brand-primary-50 focus:outline-none focus:ring-2 focus:ring-brand-primary-600"
            >
              <Menu size={24} />
            </button>
          </SheetTrigger>

          <SheetContent side="left" className="flex flex-col gap-6 p-6">
            <SheetHeader>
              {/* Visually-hidden title satisfies Radix a11y */}
              <SheetTitle className="sr-only">Main navigation</SheetTitle>

              {/* Brand inside drawer */}
              <Link href="/" className="flex items-center gap-2">
                <span className="h-6 w-6 rounded-md bg-gradient-to-br from-brand-primary-500 to-brand-accent-500" />
                <span className="font-semibold tracking-tight">
                  Junaid<span className="text-brand-primary-500">·</span>
                  Portfolio
                </span>
              </Link>
            </SheetHeader>

            <ul className="flex flex-col gap-4 text-lg">
              {links.map(({ href, label }) => {
                const isActive =
                  href === "/" ? pathname === "/" : pathname.startsWith(href);
                return (
                  <li key={href}>
                    <SheetClose asChild>
                      <Link
                        href={href}
                        className={`${base} ${isActive ? active : ""}`}
                      >
                        {label}
                      </Link>
                    </SheetClose>
                  </li>
                );
              })}
            </ul>
          </SheetContent>
        </Sheet>
      </nav>
    </header>
  );
}
