// src/components/Footer.tsx
"use client";

import CTA from "@/components/CTA";
import Link from "next/link";
import { Github, Linkedin, X as XIcon } from "lucide-react";

export default function Footer() {
  const year = new Date().getFullYear();

  return (
    <>
      <CTA />

      {/* footer proper */}
      <footer className="bg-brand-bg">
        <div className="mx-auto max-w-6xl px-6 pt-14 pb-16 flex flex-col items-center space-y-8 text-center">
          {/* monogram */}
          <div className="h-12 w-12 rounded-full bg-white flex items-center justify-center text-step-0 font-semibold text-brand-text">
            JG
          </div>

          {/* tagline */}
          <p className="text-step--1 text-brand-text/90">
            Living, learning, &amp; leveling up one day at a time.
          </p>

          {/* social icons */}
          <div className="flex space-x-8">
            <Link
              href="https://github.com/JunaidGool"
              target="_blank"
              aria-label="GitHub"
            >
              <Github className="h-6 w-6 text-white hover:opacity-80" />
            </Link>
            <Link
              href="https://linkedin.com/in/JunaidGool"
              target="_blank"
              aria-label="LinkedIn"
            >
              <Linkedin className="h-6 w-6 text-white hover:opacity-80" />
            </Link>
            <Link
              href="https://twitter.com/JunaidGool"
              target="_blank"
              aria-label="X / Twitter"
            >
              <XIcon className="h-6 w-6 text-white hover:opacity-80" />
            </Link>
          </div>

          {/* copyright */}
          <p className="text-step--1 text-brand-text/70">
            © {year} junaidgool.com
          </p>
        </div>
      </footer>
    </>
  );
}
