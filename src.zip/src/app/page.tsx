"use client";

import Hero from "@/components/Hero";
import ProductCard from "@/components/ProductCard";

export default function Home() {
  return (
    <>
      <Hero />

      {/* ───────────── PRODUCT STRIP ───────────── */}
      <section
        id="projects"
        className="
          py-space-3xl
          mb-space-7xl lg:mb-space-7xl  
          bg-brand-bg
        "
      >
        <div className="container mx-auto">
          <div className="grid gap-12 lg:grid-cols-2">
            <ProductCard
              title="ShapLink"
              img="/brand/shaplink-thumb.png"
              blurb="One API & dashboard to generate PayShap + Capitec Pay links via a single webhook."
              href="/products/shaplink"
              status="in-flight"
            />
            <ProductCard
              title="StokFolio"
              img="/brand/stokfolio-thumb.png"
              blurb="Real-time cockpit for stokvels — collect contributions, track balances, run votes."
              href="/products/stokfolio"
              status="in-flight"
            />
          </div>
        </div>
      </section>
    </>
  );
}
